import java.util.Properties;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Random;

public class SendOTP {
	static int length;
  public static void sendMail(){
			// Recipient's email ID needs to be mentioned.
	      String to = "sonurajput1505@gmail.com";
	      Random random = new Random();
		  int OTP= random.nextInt(123456);
	      // Sender's email ID needs to be mentioned
	      String from = "kirtirajput759@gmail.com";
	      final String username = "kirtirajput759@gmail.com";//change accordingly
	      final String password = "bidfeqglwklfryug";//change accordingly

	      // Assuming you are sending email through relay.jangosmtp.net
	      String host = "smtp.gmail.com";

	      Properties props = new Properties();
	      props.put("mail.smtp.auth", "true");
	      props.put("mail.smtp.starttls.enable", true);
	      props.put("mail.smtp.host", host);
	      props.put("mail.smtp.port", 465);
		  props.put("mail.smtp.EnableSSL.enable","true");
		  props.setProperty("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");   
		  props.setProperty("mail.smtp.socketFactory.fallback", "false");   
	      props.setProperty("mail.smtp.port", "465");   
	      props.setProperty("mail.smtp.socketFactory.port", "465"); 

	      // Get the Session object.
	      Session session = Session.getInstance(props,
	         new javax.mail.Authenticator() {
	            protected PasswordAuthentication getPasswordAuthentication() {
	               return new PasswordAuthentication(username, password);
		   }
	         });

	      try {
		   // Create a default MimeMessage object.
		   Message message = new MimeMessage(session);
		
		   // Set From: header field of the header.
		   message.setFrom(new InternetAddress("kirtirajput1508@gmail.com"));
		
		   // Set To: header field of the header.
		   message.setRecipients(Message.RecipientType.TO,
	               InternetAddress.parse("sonurajput1505@gmail.com"));
		
		   // Set Subject: header field
		   message.setSubject("OTP Message");
		
		   // Now set the actual message
		   message.setText("Your OTP for verification is:"+OTP);

		   // Send message
		   Transport.send(message);

		   System.out.println("Sent OTP message successfully on Gmail....");

	      } catch (Exception e) {
	         e.printStackTrace();
	      }
	   }
	   
    public static void main(String[] args) {
	      sendMail();
	   }
	  }

